# Test evidence

Add your original screenshots here before submitting the repository.

Suggested screenshots:
1. Desktop homepage header/navigation.
2. Mobile menu open.
3. Contact form empty/invalid email validation (avoid exposing personal data).
4. Lighthouse Services-page summary showing all four scores.
5. Lighthouse metrics showing FCP, LCP, Speed Index, TBT and CLS.
6. Lighthouse diagnostics showing render-blocking resources and JavaScript findings.
7. HTTP-to-HTTPS redirect, with the final HTTPS address visible.

Use descriptive filenames, for example:
- `desktop-header.png`
- `mobile-menu-open.png`
- `contact-form-validation.png`
- `lighthouse-services-mobile-summary.png`

Do not edit screenshots to change results. Hide personal information if present.
